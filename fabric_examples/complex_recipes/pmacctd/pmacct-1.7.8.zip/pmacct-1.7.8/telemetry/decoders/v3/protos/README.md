Placeholder for the proto file and their generated code.
