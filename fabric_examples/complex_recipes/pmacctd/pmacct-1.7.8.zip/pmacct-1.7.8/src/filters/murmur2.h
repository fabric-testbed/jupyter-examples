#ifndef MURMUR2_H
#define MURMUR2_H

/* prototypes */
extern unsigned int murmurhash2(const void *, int, const unsigned int);

#endif //MURMUR2_H
